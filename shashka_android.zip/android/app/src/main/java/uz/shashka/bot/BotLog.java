package uz.shashka.bot;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/** Holat qatori va log (ilovada ko'rsatiladi, "Logni ulashish" tugmasi orqali yuboriladi). */
final class BotLog {
    private BotLog() {}

    static volatile String status = "To'xtatilgan";
    private static final ArrayDeque<String> lines = new ArrayDeque<>();
    private static volatile File file = null;
    private static final SimpleDateFormat FMT = new SimpleDateFormat("HH:mm:ss", Locale.US);

    static void setFile(File f) {
        try { if (f != null && f.length() > 40_000_000L) f.delete(); } catch (Exception ignored) { }   // juda katta bo'lib ketsa tozalaymiz
        file = f;
    }

    static void say(String s) {
        status = s;
        log("» " + s);
    }

    private static String lastMsg = "";

    static synchronized void log(String s) {
        if (s.equals(lastMsg) && s.startsWith("» Taxta")) return;   // bir xil "taxta topilmadi" qatorlari log'ni to'ldirmasin
        lastMsg = s;
        String line = FMT.format(new Date()) + " " + s;
        lines.addLast(line);
        while (lines.size() > 4000) lines.removeFirst();
        System.out.println(line);
        File f = file;
        if (f != null) {
            try (FileWriter w = new FileWriter(f, true)) {
                w.write(line + "\n");
            } catch (Exception ignored) {
            }
        }
    }

    static synchronized String tail(int n) {
        StringBuilder sb = new StringBuilder();
        int skip = Math.max(0, lines.size() - n);
        int i = 0;
        for (String l : lines) {
            if (i++ >= skip) sb.append(l).append('\n');
        }
        return sb.toString();
    }
}
