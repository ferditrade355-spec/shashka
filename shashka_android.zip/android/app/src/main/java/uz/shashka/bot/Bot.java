package uz.shashka.bot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/** O'yin sikli: taxtani o'qiydi, navbat sizda bo'lsa dvigateldan yurish olib, ekranga bosadi. */
final class Bot extends Thread {
    private static final String[] MODES = {"click", "slow", "steps", "drag", "slow"};

    private final Screen screen;
    private final Tapper tapper;
    private final EngineClient eng;
    private final Random rnd = new Random();
    private volatile boolean stopFlag = false;

    Bot(Screen screen, Tapper tapper, EngineClient eng) {
        super("shashka-bot");
        setDaemon(true);
        this.screen = screen;
        this.tapper = tapper;
        this.eng = eng;
    }

    void requestStop() {
        stopFlag = true;
        interrupt();
    }

    private boolean nap(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            return false;
        }
        return !stopFlag;
    }

    @Override
    public void run() {
        try {
            loop();
        } catch (Throwable e) {
            BotLog.say("Xato: " + e);
            java.io.StringWriter sw = new java.io.StringWriter();
            e.printStackTrace(new java.io.PrintWriter(sw));
            BotLog.log(sw.toString());
        }
        eng.close();
        BotLog.say("To'xtatildi");
    }

    static String boardStr(int[][] b) {
        StringBuilder sb = new StringBuilder(64);
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                int v = b[r][c];
                sb.append(v == 1 ? 'o' : v == 2 ? 'O' : v == -1 ? 'x' : v == -2 ? 'X' : '.');
            }
        }
        return sb.toString();
    }

    static String sig(int[][] b) {
        StringBuilder sb = new StringBuilder(64);
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) sb.append(b[r][c] > 0 ? '+' : b[r][c] < 0 ? '-' : '.');
        return sb.toString();
    }

    static int[][] toEngine(char[][] cb, char mine) {
        int[][] b = new int[8][8];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                char ch = cb[r][c];
                if (ch == 0 || ch == 'e') continue;
                int k = Character.isUpperCase(ch) ? 2 : 1;
                b[r][c] = Character.toLowerCase(ch) == mine ? k : -k;
            }
        }
        return b;
    }

    /** Yo'l bo'yicha yurishni taxtaga qo'llaydi (olingan shashkalar yo'ldagi kataklardan olinadi). */
    static int[][] applyMove(int[][] b, int[] path) {
        int[][] nb = new int[8][8];
        for (int r = 0; r < 8; r++) nb[r] = b[r].clone();
        int r0 = path[0] / 8, c0 = path[0] % 8;
        int piece = nb[r0][c0];
        boolean king = Math.abs(piece) == 2;
        nb[r0][c0] = 0;
        for (int i = 1; i < path.length; i++) {
            int ra = path[i - 1] / 8, ca = path[i - 1] % 8, rb = path[i] / 8, cb = path[i] % 8;
            int dr = Integer.signum(rb - ra), dc = Integer.signum(cb - ca);
            int r = ra + dr, c = ca + dc;
            while (r != rb || c != cb) {
                if (nb[r][c] < 0) nb[r][c] = 0;
                r += dr;
                c += dc;
            }
            if (rb == 0) king = true;
        }
        int rl = path[path.length - 1] / 8, cl = path[path.length - 1] % 8;
        nb[rl][cl] = king ? 2 : 1;
        return nb;
    }

    static String sq(int idx) {
        return "" + (char) ('a' + idx % 8) + (8 - idx / 8);
    }

    static String fmt(int[] path) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.length; i++) {
            if (i > 0) sb.append(">");
            sb.append(sq(path[i]));
        }
        return sb.toString();
    }

    private float[] center(int[] bb, int idx) {
        double cw = (bb[2] - bb[0]) / 8.0, ch = (bb[3] - bb[1]) / 8.0;
        double jx = (rnd.nextDouble() - 0.5) * cw * 0.25, jy = (rnd.nextDouble() - 0.5) * ch * 0.25;
        return new float[]{(float) (bb[0] + (idx % 8 + 0.5) * cw + jx), (float) (bb[1] + (idx / 8 + 0.5) * ch + jy)};
    }

    private void play(int[] bb, int[] path, String mode, double mult) {
        boolean slow = mode.equals("slow");
        List<float[]> pts = new ArrayList<>();
        if (mode.equals("steps")) {
            for (int p : path) pts.add(center(bb, p));
        } else {
            pts.add(center(bb, path[0]));
            pts.add(center(bb, path[path.length - 1]));
        }
        if (mode.equals("drag")) {
            for (int i = 0; i + 1 < pts.size(); i++) {
                if (stopFlag) return;
                float[] a = pts.get(i), b = pts.get(i + 1);
                tapper.swipe(a[0], a[1], b[0], b[1], 350);
                nap((long) (600 * mult));
            }
        } else {
            for (int i = 0; i < pts.size(); i++) {
                if (stopFlag) return;
                float[] a = pts.get(i);
                tapper.tap(a[0], a[1], slow ? 140 : 60);
                nap((long) (((slow ? (i == 0 ? 700 : 600) : (i == 0 ? 500 : 350))) * mult));
            }
        }
    }

    private void loop() {
        int[] bb = null;
        char mine = 0;
        String lastBefore = null, lastAfter = null;
        int[] sentKey = null;
        long tSent = 0;
        int fails = 0, unstable = 0, badReads = 0, noFrame = 0;
        List<int[]> excluded = new ArrayList<>();
        List<String> seen = new ArrayList<>();
        Boolean lastTurn = null;
        String lastSayWait = "";

        BotLog.say("Ishga tushdi. Gramora ochiq bo'lsin.");
        while (!stopFlag) {
            Frame f1 = screen.grab();
            if (f1 == null) {
                if (++noFrame == 20) BotLog.say("Ekran tasviri kelmayapti");
                if (!nap(200)) break;
                continue;
            }
            noFrame = 0;
            if (bb == null) {
                bb = Vision.detectBoard(f1);
                if (bb == null) {
                    BotLog.say("Taxta topilmadi. Telegram'da Gramora o'yini ochiq turibdimi?");
                    if (!nap(800)) break;
                    continue;
                }
                BotLog.log("taxta topildi: " + Arrays.toString(bb) + " ekran " + f1.w + "x" + f1.h);
            }
            char[][] cb1 = Vision.classify(f1, bb);
            Boolean t1 = Vision.myTurn(f1, bb);
            if (!nap(120)) break;
            Frame f2 = screen.grab();
            if (f2 == null) f2 = f1;
            char[][] cb = Vision.classify(f2, bb);
            Boolean t2 = Vision.myTurn(f2, bb);
            if (!Arrays.deepEquals(cb1, cb)) {
                if (++unstable == 4) BotLog.say("Taxta harakatda (animatsiya). Kutyapman...");
                continue;
            }
            unstable = 0;
            Boolean turn = (Boolean.TRUE.equals(t1) || Boolean.TRUE.equals(t2)) ? Boolean.TRUE
                    : (Boolean.FALSE.equals(t1) || Boolean.FALSE.equals(t2)) ? Boolean.FALSE : null;
            if (!Vision.valid(cb)) {
                BotLog.say("Taxta o'qilmadi. Qayta qidiryapman...");
                if (++badReads >= 3) {
                    bb = null;
                    badReads = 0;
                }
                if (!nap(700)) break;
                continue;
            }
            badReads = 0;

            if (Vision.isInitial(cb) && (mine == 0 || lastAfter != null)) {
                mine = Vision.detectColor(cb);
                lastBefore = lastAfter = null;
                fails = 0;
                excluded.clear();
                seen.clear();
                eng.newGame();
                BotLog.say("Yangi o'yin. Siz: " + (mine == 'w' ? "OQ" : "QORA") + ".");
                if (turn != null && ((turn && mine == 'b') || (!turn && mine == 'w')))
                    BotLog.log("OGOHLANTIRISH: navbat belgisi rang bilan mos kelmayapti (oq birinchi yuradi)");
            }
            if (mine == 0) {
                mine = Vision.detectColor(cb);
                BotLog.say("O'yin o'rtasidan qo'shildim. Siz: " + (mine == 'w' ? "OQ" : "QORA") + ".");
            }
            int[][] vis = toEngine(cb, mine);
            String cur = sig(vis);

            if (turn != null && !turn) {
                if (!"w".equals(lastSayWait)) BotLog.say("Raqib o'ylayapti. Kutyapman...");
                lastSayWait = "w";
                if (!nap(150)) break;
                continue;
            }
            lastSayWait = "";
            if (turn == null && lastTurn != null) BotLog.say("Navbat belgisi ko'rinmayapti.");
            lastTurn = turn;

            if (lastAfter != null) {
                if (cur.equals(lastAfter)) {
                    if (!nap(300)) break;
                    continue;
                }
                if (cur.equals(lastBefore)) {
                    if (System.currentTimeMillis() - tSent < 1300) {
                        if (!nap(250)) break;
                        continue;
                    }
                    fails++;
                    BotLog.log("yurish o'tmadi (" + fails + "-marta), usul: " + MODES[Math.min(fails - 1, 4)]);
                    if (fails >= 6) {
                        BotLog.say("Yurish qabul qilinmayapti (6 marta). Pauza. Logni yuboring.");
                        return;
                    }
                    if (fails == 4 && sentKey != null) excluded.add(sentKey);
                    BotLog.say("Yurish o'tmadi. Boshqa usul bilan qayta urinaman (" + fails + ")...");
                } else {
                    fails = 0;
                    excluded.clear();
                }
            }

            if (!tapper.available()) {
                BotLog.say("Accessibility xizmati yoqilmagan! Sozlamalarda yoqing.");
                if (!nap(1500)) break;
                continue;
            }

            int pieces = 0;
            for (int[] row : vis) for (int v : row) if (v != 0) pieces++;
            long think = pieces >= 22 ? 600 : 1500;
            List<String> seenTail = seen.size() > 150 ? seen.subList(seen.size() - 150, seen.size()) : seen;
            BotLog.log("taxta: " + boardStr(vis));
            int[] path = eng.go(boardStr(vis), excluded, think, seenTail);
            if (path == null || path.length < 2) {
                BotLog.say("Dvigatel yurish bermadi (o'yin tugagan yoki dvigatel ishlamayapti).");
                if (!nap(1500)) break;
                continue;
            }
            int[][] after = applyMove(vis, path);
            eng.ponder(boardStr(after));
            String mode = MODES[Math.min(fails, 4)];
            BotLog.say("Yuryapman: " + fmt(path) + " (" + mode + ")");
            BotLog.log("yuraman: " + fmt(path) + " usul=" + mode);
            play(bb, path, mode, 1.0 + 0.6 * fails);
            lastBefore = cur;
            lastAfter = sig(after);
            sentKey = new int[]{path[0], path[path.length - 1]};
            tSent = System.currentTimeMillis();
            seen.add(boardStr(after));
        }
    }
}
