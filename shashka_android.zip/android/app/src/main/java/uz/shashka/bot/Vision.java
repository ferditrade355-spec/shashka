package uz.shashka.bot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Taxtani ekran tasvirida topish va kataklarni o'qish (shashka.py dagi kodning Java varianti). */
final class Vision {
    private Vision() {}

    private static boolean beige(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        return r > 150 && r >= g && g > b && (r - b) > 32 && (r - b) < 90 && g > 110;
    }

    /** {x1,y1,x2,y2} yoki null. */
    static int[] detectBoard(Frame f) {
        final int W = f.w, H = f.h;
        boolean[] m = new boolean[W * H];
        for (int i = 0; i < m.length; i++) m[i] = beige(f.rgb[i]);
        final int st = 3;
        int H2 = (H / st) * st, W2 = (W / st) * st;
        int h = H2 / st, w = W2 / st;
        boolean[] ms = new boolean[h * w];
        for (int y = 0; y < H2; y++) {
            int row = (y / st) * w;
            int base = y * W;
            for (int x = 0; x < W2; x++) if (m[base + x]) ms[row + x / st] = true;
        }
        for (int it = 0; it < 2; it++) {
            boolean[] d = ms.clone();
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    if (ms[y * w + x]) continue;
                    boolean any = false;
                    for (int dy = -1; dy <= 1 && !any; dy++) {
                        int yy = y + dy;
                        if (yy < 0 || yy >= h) continue;
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx;
                            if (xx < 0 || xx >= w) continue;
                            if (ms[yy * w + xx]) { any = true; break; }
                        }
                    }
                    if (any) d[y * w + x] = true;
                }
            }
            ms = d;
        }
        boolean[] seen = new boolean[h * w];
        List<int[]> cands = new ArrayList<>();   // {area, x0, y0, x1, y1}
        int[] queue = new int[h * w];
        for (int y0 = 0; y0 < h; y0++) {
            for (int x0 = 0; x0 < w; x0++) {
                int s0 = y0 * w + x0;
                if (!ms[s0] || seen[s0]) continue;
                int qh = 0, qt = 0;
                queue[qt++] = s0;
                seen[s0] = true;
                int mny = y0, mxy = y0, mnx = x0, mxx = x0;
                while (qh < qt) {
                    int cur = queue[qh++];
                    int y = cur / w, x = cur % w;
                    if (y < mny) mny = y;
                    if (y > mxy) mxy = y;
                    if (x < mnx) mnx = x;
                    if (x > mxx) mxx = x;
                    if (y + 1 < h && ms[cur + w] && !seen[cur + w]) { seen[cur + w] = true; queue[qt++] = cur + w; }
                    if (y - 1 >= 0 && ms[cur - w] && !seen[cur - w]) { seen[cur - w] = true; queue[qt++] = cur - w; }
                    if (x + 1 < w && ms[cur + 1] && !seen[cur + 1]) { seen[cur + 1] = true; queue[qt++] = cur + 1; }
                    if (x - 1 >= 0 && ms[cur - 1] && !seen[cur - 1]) { seen[cur - 1] = true; queue[qt++] = cur - 1; }
                }
                int bw = mxx - mnx + 1, bh = mxy - mny + 1;
                double ar = (double) bw / bh;
                if (bw >= 30 && bh >= 30 && ar >= 0.85 && ar <= 1.18) {
                    cands.add(new int[]{bw * bh, mnx * st, mny * st, (mxx + 1) * st, (mxy + 1) * st});
                }
            }
        }
        Collections.sort(cands, new Comparator<int[]>() {
            @Override
            public int compare(int[] a, int[] b) { return Integer.compare(b[0], a[0]); }
        });
        for (int i = 0; i < Math.min(5, cands.size()); i++) {
            int[] c = cands.get(i);
            int mx = 14;
            int X0 = Math.max(0, c[1] - mx), Y0 = Math.max(0, c[2] - mx);
            int X1 = Math.min(W, c[3] + mx), Y1 = Math.min(H, c[4] + mx);
            int rw = X1 - X0, rh = Y1 - Y0;
            boolean[] reg = new boolean[rw * rh];
            for (int y = 0; y < rh; y++) System.arraycopy(m, (Y0 + y) * W + X0, reg, y * rw, rw);
            double[] res = fitGrid(reg, rw, rh);
            if (res != null) {
                int gx = (int) res[0], gy = (int) res[1], gs = (int) res[2];
                return new int[]{X0 + gx, Y0 + gy, X0 + gx + 8 * gs, Y0 + gy + 8 * gs};
            }
        }
        return null;
    }

    private static double score(int[] I, int stride, int w, int h, int x0, int y0, int s) {
        double lightSum = 0, darkSum = 0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                int xa = (int) (x0 + c * s + 0.07 * s), xb = (int) (x0 + c * s + 0.93 * s);
                int ya = (int) (y0 + r * s + 0.07 * s), yb = (int) (y0 + r * s + 0.93 * s);
                if (xb > w || yb > h || xa < 0 || ya < 0) return -1;
                long tot = (long) I[yb * stride + xb] - I[ya * stride + xb] - I[yb * stride + xa] + I[ya * stride + xa];
                double f = (double) tot / Math.max(1, (xb - xa) * (yb - ya));
                if (((r + c) & 1) == 0) lightSum += f; else darkSum += f;
            }
        }
        return lightSum / 32.0 - darkSum / 32.0;
    }

    /** {x0, y0, s, score} yoki null. */
    private static double[] fitGrid(boolean[] reg, int w, int h) {
        int ext = Math.min(h, w);
        if (ext < 100) return null;
        int stride = w + 1;
        int[] I = new int[(h + 1) * stride];
        for (int y = 0; y < h; y++) {
            int acc = 0;
            for (int x = 0; x < w; x++) {
                if (reg[y * w + x]) acc++;
                I[(y + 1) * stride + (x + 1)] = I[y * stride + (x + 1)] + acc;
            }
        }
        double bestSc = -1;
        int bx = 0, by = 0, bs = 0;
        int sLo = (int) (ext * 0.75 / 8), sHi = (int) (ext / 8) + 1;
        for (int s = sLo; s <= sHi; s++) {
            if (s < 12) continue;
            int yMax = Math.max(1, h - 8 * s + 1), xMax = Math.max(1, w - 8 * s + 1);
            for (int y0 = 0; y0 < yMax; y0 += 2) {
                for (int x0 = 0; x0 < xMax; x0 += 2) {
                    double sc = score(I, stride, w, h, x0, y0, s);
                    if (sc > bestSc) { bestSc = sc; bx = x0; by = y0; bs = s; }
                }
            }
        }
        int cx = bx, cy = by, cs = bs;
        for (int s = bs - 3; s <= bs + 3; s++) {
            for (int y0 = by - 4; y0 <= by + 4; y0++) {
                for (int x0 = bx - 4; x0 <= bx + 4; x0++) {
                    double sc2 = score(I, stride, w, h, x0, y0, s);
                    if (sc2 > bestSc) { bestSc = sc2; cx = x0; cy = y0; cs = s; }
                }
            }
        }
        if (bestSc > 0.8) return new double[]{cx, cy, cs, bestSc};
        return null;
    }

    /** 8x8: 0 = o'ynalmaydigan katak, 'e' bo'sh, 'w'/'b' shashka, 'W'/'B' damka. */
    static char[][] classify(Frame f, int[] bb) {
        int x1 = bb[0], y1 = bb[1];
        double ch = (bb[3] - bb[1]) / 8.0, cw = (bb[2] - bb[0]) / 8.0;
        char[][] out = new char[8][8];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                if ((r + c) % 2 == 0) continue;
                int y0 = (int) (r * ch + ch * 0.12), yy1 = (int) ((r + 1) * ch - ch * 0.12);
                int xx0 = (int) (c * cw + cw * 0.12), xx1 = (int) ((c + 1) * cw - cw * 0.12);
                int n = 0, ringCount = 0;
                for (int y = y0; y < yy1; y++) {
                    for (int x = xx0; x < xx1; x++) {
                        int p = pix(f, x1 + x, y1 + y);
                        int rr = (p >> 16) & 255, gg = (p >> 8) & 255, bl = p & 255;
                        n++;
                        if (rr - gg > 25 && rr - bl > 25) ringCount++;
                    }
                }
                boolean dropRing = n > 0 && (double) ringCount / n > 0.015 && (n - ringCount) >= 20;
                double sum = 0, sumPix = 0, sumPix2 = 0;
                long cnt = 0;
                for (int y = y0; y < yy1; y++) {
                    for (int x = xx0; x < xx1; x++) {
                        int p = pix(f, x1 + x, y1 + y);
                        int rr = (p >> 16) & 255, gg = (p >> 8) & 255, bl = p & 255;
                        if (dropRing && rr - gg > 25 && rr - bl > 25) continue;
                        double pm = (rr + gg + bl) / 3.0;
                        sum += rr + gg + bl;
                        sumPix += pm;
                        sumPix2 += pm * pm;
                        cnt++;
                    }
                }
                if (cnt == 0) { out[r][c] = 'e'; continue; }
                double mean = sum / (3.0 * cnt) / 255.0;
                double mp = sumPix / cnt;
                double var = sumPix2 / cnt - mp * mp;
                double std = Math.sqrt(Math.max(0, var)) / 80.0;
                char kind;
                if (mean > 0.45) kind = 'w';
                else if (std > 0.17) kind = 'b';
                else { out[r][c] = 'e'; continue; }
                int cy0 = (int) (r * ch + ch * 0.30), cy1 = (int) ((r + 1) * ch - ch * 0.30);
                int cx0 = (int) (c * cw + cw * 0.30), cx1 = (int) ((c + 1) * cw - cw * 0.30);
                int gold = 0, tot = 0;
                for (int y = cy0; y < cy1; y++) {
                    for (int x = cx0; x < cx1; x++) {
                        int p = pix(f, x1 + x, y1 + y);
                        int rr = (p >> 16) & 255, gg = (p >> 8) & 255, bl = p & 255;
                        tot++;
                        if (rr > 150 && gg > 100 && bl < 120 && rr - bl > 70 && gg - bl > 40) gold++;
                    }
                }
                boolean isGold = tot > 0 && (double) gold / tot > 0.03;
                out[r][c] = isGold ? Character.toUpperCase(kind) : kind;
            }
        }
        return out;
    }

    private static int pix(Frame f, int x, int y) {
        if (x < 0 || y < 0 || x >= f.w || y >= f.h) return 0;
        return f.rgb[y * f.w + x];
    }

    /** Yashil "SIZNING NAVBATINGIZ" belgisi: true/false; o'qib bo'lmasa null. */
    static Boolean myTurn(Frame f, int[] bb) {
        int Hb = bb[3] - bb[1], Wb = bb[2] - bb[0];
        int ya = bb[1] + (int) (Hb * 1.08), yb = bb[1] + (int) (Hb * 1.26);
        int xa = bb[0] + (int) (Wb * 0.2), xb = bb[0] + (int) (Wb * 0.8);
        yb = Math.min(yb, f.h);
        xb = Math.min(xb, f.w);
        if (yb <= ya || xb <= xa) return null;
        long green = 0, tot = 0;
        for (int y = ya; y < yb; y++) {
            for (int x = xa; x < xb; x++) {
                int p = f.rgb[y * f.w + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                tot++;
                if (g > 110 && g > r + 35 && g > b + 35) green++;
            }
        }
        return tot > 0 && (double) green / tot > 0.002;
    }

    static boolean valid(char[][] cb) {
        int nw = 0, nb = 0;
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            if (cb[r][c] == 'w' || cb[r][c] == 'W') nw++;
            if (cb[r][c] == 'b' || cb[r][c] == 'B') nb++;
        }
        return nw > 0 && nw <= 12 && nb > 0 && nb <= 12;
    }

    static boolean isInitial(char[][] cb) {
        boolean[] top = new boolean[256], bot = new boolean[256];
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            char v = cb[r][c];
            if (v == 0) continue;
            if (r == 3 || r == 4) { if (v != 'e') return false; }
            else if (r <= 2) top[v] = true;
            else bot[v] = true;
        }
        int nt = 0, nbt = 0;
        char tc = 0, bc = 0;
        for (int i = 0; i < 256; i++) { if (top[i]) { nt++; tc = (char) i; } if (bot[i]) { nbt++; bc = (char) i; } }
        if (nt != 1 || nbt != 1 || tc == bc) return false;
        return (tc == 'w' || tc == 'b') && (bc == 'w' || bc == 'b');
    }

    /** Sizning shashkalaringiz ekranning pastida turadi. 'w' yoki 'b'. */
    static char detectColor(char[][] cb) {
        double[] sc = new double[2], rows = new double[2];
        int[] cnt = new int[2];
        char[] cols = {'w', 'b'};
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            char v = cb[r][c];
            if (v == 0 || v == 'e') continue;
            int k = Character.toLowerCase(v) == 'w' ? 0 : 1;
            sc[k] += r >= 4 ? 1 : -1;
            rows[k] += r;
            cnt[k]++;
        }
        if (sc[0] != sc[1]) return sc[0] > sc[1] ? cols[0] : cols[1];
        double m0 = cnt[0] > 0 ? rows[0] / cnt[0] : 3.5, m1 = cnt[1] > 0 ? rows[1] / cnt[1] : 3.5;
        return m0 >= m1 ? 'w' : 'b';
    }
}
