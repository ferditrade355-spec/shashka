package uz.shashka.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 100;
    private TextView statusView, logView, accView;
    private final Handler h = new Handler();
    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            statusView.setText("Holat: " + BotLog.status + (CaptureService.running ? "  [ISHLAYAPTI]" : ""));
            accView.setText("Accessibility (bosish) xizmati: " + (TapService.inst != null ? "YOQILGAN" : "o'chiq"));
            logView.setText(BotLog.tail(40));
            h.postDelayed(this, 700);
        }
    };

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        BotLog.setFile(new java.io.File(getFilesDir(), "shashka_log.txt"));
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Shashka bot (Gramora)");
        title.setTextSize(22);
        root.addView(title);

        accView = new TextView(this);
        root.addView(accView);
        statusView = new TextView(this);
        statusView.setTextSize(16);
        root.addView(statusView);

        root.addView(button("1) Accessibility sozlamalarini ochish", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));
        root.addView(button("Cheklangan sozlamalar (ilova ma'lumoti)", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            }
        }));
        root.addView(button("2) BOSHLASH (ekran yozishga ruxsat)", new View.OnClickListener() {
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                }
                MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
            }
        }));
        root.addView(button("TO'XTATISH", new View.OnClickListener() {
            public void onClick(View v) {
                startService(new Intent(MainActivity.this, CaptureService.class).setAction(CaptureService.ACTION_STOP));
            }
        }));
        root.addView(button("Logni ulashish (menga yuborish uchun)", new View.OnClickListener() {
            public void onClick(View v) {
                String t = BotLog.tail(300);
                if (t.length() > 60000) t = t.substring(t.length() - 60000);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, t);
                startActivity(Intent.createChooser(i, "Logni yuborish"));
            }
        }));

        TextView hint = new TextView(this);
        hint.setText("Tartib: 1) Accessibility'da \"Shashka bot\"ni yoqing. 2) BOSHLASH, \"Butun ekran\" ni tanlang. 3) Telegram'da Gramora o'yinini oching.");
        hint.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(hint);

        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(10);
        ScrollView sv = new ScrollView(this);
        sv.addView(logView);
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(refresh);
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(refresh);
        super.onPause();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE) {
            if (res == RESULT_OK && data != null) {
                Intent i = new Intent(this, CaptureService.class);
                i.putExtra("code", res);
                i.putExtra("data", data);
                startForegroundService(i);
                BotLog.say("Ekran yozishga ruxsat berildi. Endi Telegram'da Gramora'ni oching.");
            } else {
                BotLog.say("Ekran yozishga ruxsat berilmadi.");
            }
        }
    }
}
