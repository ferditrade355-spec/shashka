package uz.shashka.bot;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** C dvigatel (engine --server) bilan muloqot. Yo'l: libengine.so (ARM64) yoki kompyuterdagi sinov uchun oddiy fayl. */
final class EngineClient {
    private final String exe;
    private Process proc;
    private BufferedWriter out;
    private LinkedBlockingQueue<String> q = new LinkedBlockingQueue<>();
    private int fails = 0;

    EngineClient(String exe) {
        this.exe = exe;
    }

    /** "VER 2" ni qaytaradi, bo'lmasa null. */
    String version() {
        try {
            Process p = new ProcessBuilder(exe, "--version").redirectErrorStream(true).start();
            p.getOutputStream().close();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String l = r.readLine();
            p.waitFor(3, TimeUnit.SECONDS);
            return l;
        } catch (Exception e) {
            BotLog.log("dvigatel versiyasi o'qilmadi: " + e);
            return null;
        }
    }

    private boolean alive() {
        if (proc == null) return false;
        try {
            proc.exitValue();
            return false;
        } catch (IllegalThreadStateException e) {
            return true;
        }
    }

    private synchronized boolean ensure() {
        if (alive()) return true;
        if (fails >= 3) return false;
        try {
            proc = new ProcessBuilder(exe, "--server").start();
            out = new BufferedWriter(new OutputStreamWriter(proc.getOutputStream()));
            final LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<>();
            q = queue;
            final InputStream is = proc.getInputStream();
            final InputStream es = proc.getErrorStream();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        BufferedReader r = new BufferedReader(new InputStreamReader(is));
                        String l;
                        while ((l = r.readLine()) != null) queue.add(l);
                    } catch (IOException ignored) {
                    }
                    queue.add("EOF");
                }
            });
            t.setDaemon(true);
            t.start();
            Thread te = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        byte[] buf = new byte[1024];
                        while (es.read(buf) >= 0) { /* stderr ni bo'shatamiz */ }
                    } catch (IOException ignored) {
                    }
                }
            });
            te.setDaemon(true);
            te.start();
            BotLog.log("dvigatel ishga tushdi");
            return true;
        } catch (Exception e) {
            fails++;
            BotLog.log("dvigatelni ishga tushirib bo'lmadi: " + e);
            return false;
        }
    }

    private void send(String s) throws IOException {
        out.write(s);
        out.flush();
    }

    synchronized void newGame() {
        if (!alive()) return;
        try {
            send("NEWGAME\n");
        } catch (IOException e) {
            kill();
        }
    }

    synchronized void ponder(String board) {
        if (!alive()) return;
        try {
            send("PONDER\n" + board + "\n");
        } catch (IOException e) {
            kill();
        }
    }

    synchronized void kill() {
        try {
            if (proc != null) proc.destroy();
        } catch (Exception ignored) {
        }
        proc = null;
    }

    synchronized void close() {
        try {
            if (alive()) {
                send("QUIT\n");
                proc.waitFor(1, TimeUnit.SECONDS);
            }
        } catch (Exception ignored) {
        }
        kill();
    }

    /** Eng yaxshi yurish yo'li (katak raqamlari r*8+c) yoki null. */
    synchronized int[] go(String board, List<int[]> excluded, long ms, List<String> seen) {
        if (!ensure()) return null;
        q.clear();
        StringBuilder sb = new StringBuilder();
        sb.append("GO ").append(ms).append('\n').append(board).append('\n');
        sb.append(excluded.size());
        for (int[] e : excluded) sb.append(' ').append(e[0]).append(' ').append(e[1]);
        sb.append('\n').append(seen.size());
        for (String s : seen) sb.append(' ').append(s);
        sb.append('\n');
        try {
            send(sb.toString());
            String line = q.poll(ms + 6000, TimeUnit.MILLISECONDS);
            if (line == null) {
                BotLog.log("dvigatel javob bermadi");
                fails++;
                kill();
                return null;
            }
            if (line.equals("EOF")) {
                BotLog.log("dvigatel to'xtab qoldi");
                fails++;
                kill();
                return null;
            }
            String[] t = line.trim().split("\\s+");
            if (t.length >= 6 && t[0].equals("OK")) {
                int len = Integer.parseInt(t[4]);
                int[] path = new int[len];
                for (int i = 0; i < len; i++) path[i] = Integer.parseInt(t[5 + i]);
                BotLog.log("dvigatel: baho=" + t[1] + " chuqurlik=" + t[2]);
                return path;
            }
            if (!line.startsWith("NONE")) BotLog.log("dvigatel javobi noma'lum: " + line);
            return null;
        } catch (Exception e) {
            BotLog.log("dvigatel xatosi: " + e);
            fails++;
            kill();
            return null;
        }
    }
}
